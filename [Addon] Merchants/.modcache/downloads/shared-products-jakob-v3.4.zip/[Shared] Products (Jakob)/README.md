# Shared Products

Please only add products that are of the same quality as the vanilla game, useful to many and really shared between mods.

Alternatively, if you have different requirements for your products you can use this mod as a template and create another shared products mod.
