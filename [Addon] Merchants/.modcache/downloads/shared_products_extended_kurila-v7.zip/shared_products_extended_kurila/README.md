# Shared Products Extended

Shared extended products from Kurila and Lrds42.

These products are planned as intermediate stages to existing production chains and have a greater impact on the vanilla game.

Contains products with definition, icon and Docklands information.

Products

- Cattle
- Cherries
- Wool Fabric
- Sewing Thread
- Barrles
- Wanza Wood
- Cherry Timber
- Spice Powder

Please only add products that are of the same quality as the vanilla game, useful to many and really shared between mods.

Alternatively, if you have different requirements for your products you can use this mod as a template and create another shared products mod.