# Shared Products

Shared products from Kurila, Jakob and Lrds42.

These products are planned as additional productions and have little influence on the vanilla game.

Contains products with definition, icon and Docklands information.

Products

- Apples
- Coloured Tiles
- Liqueur
- Sandwiches
- Smoked Fish

Please only add products that are of the same quality as the vanilla game, useful to many and really shared between mods.

Alternatively, if you have different requirements for your products you can use this mod as a template and create another shared products mod.
