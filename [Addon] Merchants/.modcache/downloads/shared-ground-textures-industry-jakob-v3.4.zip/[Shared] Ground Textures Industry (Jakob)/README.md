# Industry Ground Textures

Modular ground textures used and shared by other mods.

## Changes

- 1.0.1: Fixed stone_1x1. Preferably use concrete_stone_1x1 though.
